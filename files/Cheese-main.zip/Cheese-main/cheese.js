window.addEventListener("load", function() {
    assa()
});

function assa() {
    const iframe = document.querySelector("iframe").contentWindow.Entry.stage;
    iframe.addEventListener("load", () => {
        console.log('페이지 로딩 완료');

        let gcd=(a,c)=>c?gcd(c,a%c):a;
        gcd=gcd(3840,2160);
        const frac = [3840/gcd,2160/gcd]
        const stage = document.querySelector("iframe").contentWindow.Entry.stage;

        stage.canvas.canvas.width=3840,
        stage.canvas.canvas.height=2160,
        stage.canvas.x=1920,
        stage.canvas.y=1080,
        stage.canvas.scaleX=stage.canvas.scaleY=8,

        stage._app.stage.update();

        console.log('코드 실행 완료');
    })
}
