let a=1;
function load() {
  const button=document.querySelectorAll(".css-7ndem5")[0]
  button.addEventListener('click', function() {
    setTimeout(
      function(){
        a+=1;
        alarmData();
      },100)
  });
  
  async function alarmData(){
    var next_data = document.getElementById("__NEXT_DATA__");
    var nj = JSON.parse(next_data.innerText);
    csrf = nj.props.initialProps.csrfToken
    xtoken = nj.props.initialState.common.user.xToken
    const res = await fetch('https://playentry.org/graphql', {
      method: 'POST',
      body: JSON.stringify({"query":"\n    query SELECT_TOPICS($pageParam: PageParam, $searchAfter: JSON){\n        topicList(pageParam: $pageParam, searchAfter: $searchAfter) {\n            searchAfter\n            list {\n                \n    id\n    params\n    template\n    thumbUrl\n    category\n    target\n    isRead\n    created\n    updated\n    link {\n        category\n        target\n        hash\n        groupId\n    }\n    topicinfo {\n        category\n        targetId\n    }\n\n            }\n        }\n    }\n","variables":{"pageParam":{"display":20*a}}}),
      headers: { 
        "Content-Type": "application/json",
        "x-client-type": "Client",
        "CSRF-Token": csrf,
        "x-token": xtoken
      }
    })
    alarm = await res.json();
    alarm=alarm.data.topicList.list
    const view=document.querySelectorAll(".css-1fd2dk0")
    let li;
    comment=[]
    for (let i = 0; i < alarm.length; i++) {
      if(alarm[i].template==="template_13"){
        comment.push([alarm[i]["link"]["target"],alarm[i]["created"],i]);
      }
    }
    
    
    for (let i = 0; i < comment.length; i++) {
      
      await fetch('https://playentry.org/graphql', {
        method: 'POST',
        body: JSON.stringify({"query":"\n    query SELECT_COMMENTS(\n    $pageParam: PageParam\n    $target: String\n    $searchAfter: JSON\n    $likesLength: Int\n    $groupId: ID\n){\n        commentList(\n    pageParam: $pageParam\n    target: $target\n    searchAfter: $searchAfter\n    likesLength: $likesLength\n    groupId: $groupId\n) {\n            total\n            searchAfter\n            likesLength\n            list {\n                \n    id\n    user {\n        \n    id\n    nickname\n    username\n    profileImage {\n        \n    id\n    name\n    label {\n        \n    ko\n    en\n    ja\n    vn\n\n    }\n    filename\n    imageType\n    dimension {\n        \n    width\n    height\n\n    }\n    trimmed {\n        filename\n        width\n        height\n    }\n\n    }\n    status {\n        following\n        follower\n    }\n    description\n    role\n    mark {\n        \n    id\n    name\n    label {\n        \n    ko\n    en\n    ja\n    vn\n\n    }\n    filename\n    imageType\n    dimension {\n        \n    width\n    height\n\n    }\n    trimmed {\n        filename\n        width\n        height\n    }\n \n    }\n\n    }\n    content\n    created\n    removed\n    blamed\n    commentsLength\n    likesLength\n    isLike\n    hide\n    image {\n        \n    id\n    name\n    label {\n        \n    ko\n    en\n    ja\n    vn\n\n    }\n    filename\n    imageType\n    dimension {\n        \n    width\n    height\n\n    }\n    trimmed {\n        filename\n        width\n        height\n    }\n\n    }\n    sticker {\n        \n    id\n    name\n    label {\n        \n    ko\n    en\n    ja\n    vn\n\n    }\n    filename\n    imageType\n    dimension {\n        \n    width\n    height\n\n    }\n    trimmed {\n        filename\n        width\n        height\n    }\n\n    }\n\n            }\n        }\n    }\n","variables":{"target":comment[i][0],"pageParam":{"display":1}}}),
        headers: {           
          "Content-Type": "application/json",
          "x-client-type": "Client",
          "CSRF-Token": csrf,
          "x-token": xtoken
        }
      }).then(response => response.json())
      .then(data => {

        fetch('https://playentry.org/graphql', {
          method: 'POST',
          body: JSON.stringify({"query":"\n    query SELECT_COMMENTS(\n    $pageParam: PageParam\n    $target: String\n    $searchAfter: JSON\n    $likesLength: Int\n    $groupId: ID\n){\n        commentList(\n    pageParam: $pageParam\n    target: $target\n    searchAfter: $searchAfter\n    likesLength: $likesLength\n    groupId: $groupId\n) {\n            total\n            searchAfter\n            likesLength\n            list {\n                \n    id\n    user {\n        \n    id\n    nickname\n    username\n    profileImage {\n        \n    id\n    name\n    label {\n        \n    ko\n    en\n    ja\n    vn\n\n    }\n    filename\n    imageType\n    dimension {\n        \n    width\n    height\n\n    }\n    trimmed {\n        filename\n        width\n        height\n    }\n\n    }\n    status {\n        following\n        follower\n    }\n    description\n    role\n    mark {\n        \n    id\n    name\n    label {\n        \n    ko\n    en\n    ja\n    vn\n\n    }\n    filename\n    imageType\n    dimension {\n        \n    width\n    height\n\n    }\n    trimmed {\n        filename\n        width\n        height\n    }\n \n    }\n\n    }\n    content\n    created\n    removed\n    blamed\n    commentsLength\n    likesLength\n    isLike\n    hide\n    image {\n        \n    id\n    name\n    label {\n        \n    ko\n    en\n    ja\n    vn\n\n    }\n    filename\n    imageType\n    dimension {\n        \n    width\n    height\n\n    }\n    trimmed {\n        filename\n        width\n        height\n    }\n\n    }\n    sticker {\n        \n    id\n    name\n    label {\n        \n    ko\n    en\n    ja\n    vn\n\n    }\n    filename\n    imageType\n    dimension {\n        \n    width\n    height\n\n    }\n    trimmed {\n        filename\n        width\n        height\n    }\n\n    }\n\n            }\n        }\n    }\n","variables":{"target":comment[i][0],"pageParam":{"display":data["data"]["commentList"]["total"]}}}),
          headers: {           
            "Content-Type": "application/json",
            "x-client-type": "Client",
            "CSRF-Token": csrf,
            "x-token": xtoken
          }
        }).then(response => response.json())
        .then(data => {
          
          for (let j = 0; j < data["data"]["commentList"]["list"].length; j++) {
            date1 = new Date(data["data"]["commentList"]["list"][j]["created"]);
            date2 = new Date(comment[i][1]);
                     
            if(Math.abs(date1.getTime() - date2.getTime())<20){
              li=document.createElement('li');
              li.textContent=JSON.stringify(data["data"]["commentList"]["list"][j]["content"].replace("\n"," "));
              li.addEventListener("click",function(){open('https://playentry.org/community/entrystory/'+comment[i][0])});
              view[comment[i][2]].append(li);
              break;
            }
            
          }
          
        })

        

      })
      


    }
    
    
  };

  
  alarmData()


};
window.onload=load

